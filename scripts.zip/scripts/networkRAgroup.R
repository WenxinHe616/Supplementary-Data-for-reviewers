library(Hmisc)
data_n<-read.csv('D_bracken_abun_lefse.txt',header=T,sep = "\t")
#write.table(data_n, file = "D_bracken_abun_lefseT.txt", sep = "\t", row.names = FALSE, quote = FALSE)
species <- read.delim('D_bracken_abun_lefseT.txt', row.name = 1, check.names = FALSE)
species <- species[which(rowSums(species) >= 0), ] 
species1 <- species
species1[species1>0] <- 1
species <- species[which(rowSums(species1) >= 1), ]   
species_corr <- rcorr(t(species), type = 'spearman')
r <- species_corr$r
r[abs(r) < 0.5] <- 0
p <- species_corr$P
p1 <- p.adjust(p, method = 'BH') 
p_adjust <- p1
p1[p1>=0.05] <- -1
p1[p1<0.05 & p1>=0] <- 1
p1[p1==-1] <- 0
z <- r * p1
diag(z) <- 0    
head(z)[1:6,1:6]
#write.table(data.frame(z, check.names = FALSE), 'D_lefse_corr_.matrix.txt', col.names = NA, sep = '\t', quote = FALSE)
library(igraph)
g <- graph.adjacency(z, weighted = TRUE, mode = 'undirected')
g
g <- simplify(g)
g <- delete.vertices(g, names(degree(g)[degree(g) == 0]))
E(g)$correlation <- E(g)$weight
E(g)$weight <- abs(E(g)$weight)
tax <- read.delim('species_taxonomy.txt', row.name = 1, check.names = FALSE, stringsAsFactors = FALSE)
tax <- tax[as.character(V(g)$name), ]
V(g)$kingdom <- tax$kingdom
V(g)$phylum <- tax$phylum
V(g)$class <- tax$class
V(g)$order <- tax$order
V(g)$family <- tax$family
V(g)$species <- tax$species
g
plot(g)
adj_matrix <- as.matrix(get.adjacency(g, attr = 'correlation'))
#write.table(data.frame(adj_matrix, check.names = FALSE), 'D_network_lefseforcys_matrix.txt', col.names = NA, sep = '\t', quote = FALSE)
edge <- data.frame(as_edgelist(g)) 
edge_list <- data.frame(
  source = edge[[1]],
  target = edge[[2]],
  weight = E(g)$weight,
  correlation = E(g)$correlation
)
head(edge_list)
#write.table(edge_list, 'D_netlefse_work.edge_list.txt', sep = '\t', row.names = FALSE, quote = FALSE)
class(edge_list)
df_D <- edge_list
p_adjust_matrix <- matrix(p_adjust, nrow = 157, ncol = 157, byrow = TRUE)
rownames(p_adjust_matrix) <- rownames(p)
colnames(p_adjust_matrix) <- colnames(p)
p_values <- sapply(1:nrow(df_D), function(i) {
  source_label <- df_D$source[i]
  target_label <- df_D$target[i]
  p[source_label, target_label]
})
df_D$p <- p_values
p_adjust_values <- sapply(1:nrow(df_D), function(i) {
  source_label <- df_D$source[i]
  target_label <- df_D$target[i]
  p_adjust_matrix[source_label, target_label]
})
df_D$p_adjust <- p_adjust_values
write.table(df_D, 'D_netlefse_work_edge_list_P_adjP.txt', sep = '\t', row.names = FALSE, quote = FALSE)

