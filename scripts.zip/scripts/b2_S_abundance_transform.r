library("ggplot2")
library("reshape2")
library(vegan)
df=read.table("combine_S_transinput.txt",header=T,sep="\t",row.names=1,check.names=F)
total=read.table("kraken_unclassified_root.txt",sep="\t")
rownames(total)=total$V1
total=total[colnames(df),]
norm=df
for(i in 1:nrow(norm))
{
  for(j in 1:ncol(norm))
  {
    norm[i,j]=norm[i,j]/total$V2[j]# 每个丰度 / 相应样本的总丰度 = 相对丰度
  }
}
write.table(norm, file="SZ_S_abundance.txt", sep="\t", quote=F, row.names=T)

