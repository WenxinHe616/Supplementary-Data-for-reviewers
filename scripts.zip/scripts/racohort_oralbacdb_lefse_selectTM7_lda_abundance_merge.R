library(data.table)
library(ggplot2)
library(hrbrthemes)
dat1<-read.csv('LDA_input.txt',header=T,row.names = 1, sep = "\t")
dat1$Cluster <- factor(dat1$Cluster, levels = unique(dat1$Cluster))
pLDA<-ggplot(data=dat1,aes(x = Cluster, fill=Enrichment_group,
                           y=ifelse(
                             test=Enrichment_group=="C",
                             yes=LDA_value,
                             no=-LDA_value
                           )
)) +
  geom_bar(stat = "identity")+
  scale_fill_manual(values =c("#cc99ff", "#00d8e6"),
                    labels=c("Controls","RA"))+
  scale_y_continuous(
    labels = abs, 
    limits = max(dat1$LDA_value) * c(-1,1)
  ) + 
  coord_flip() + 
  labs(x="Cluster", y="LDA score (log10)", fill = "Group")+
  hrbrthemes::theme_ipsum()+
  theme_bw()+
  theme(panel.background = element_rect(fill = 'white'),
        panel.grid.minor.y = element_line(size=0),
        panel.grid.major = element_line(colour = "white"),
        plot.background = element_rect(fill="white"),
        axis.title.y = element_blank(),
        axis.text.y=element_blank())
pLDA

library(ggpubr)
library(ggplot2)
library(reshape2)
library(vioplot)
library(tidyverse)
data_n<-read.csv('boxplot_input.txt',header=T,sep = '\t')
head(data_n)
data1 <- melt(data_n,id="sampleID")
head (data1)
data1[data1==-8] <- NA
data2<-na.omit(data1)
#write.csv(data2,'boxplot_input_t.csv')
dat<-read.csv('boxplot_input_t.csv',header=T,row.names = 1)
group <- list(c("HC","RA"))
wilcox.test(value~group,data=dat)
?with
with(data=dat,
     wilcox.test(x=value,g=group,p.adjust.method = "fdr"))
order<-unique(dat1$Cluster)
dat$variable<-factor(dat$variable, levels = order)
#dat$variable <- factor(dat1$Cluster, levels = unique(dat1$Cluster))
abun<-ggplot(dat, aes(x=variable, y = value, fill = factor(group))) +
  coord_flip()+
  labs(x="Cluster", y="Log10(Abundance)", fill = "Group")+
  theme_bw()+
  #stat_compare_means(comparisons=groups,method="t.test",label="p.signif")+
  stat_compare_means(aes(group=group),
                     method="wilcox.test",
                     #symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1),
                      #                symbols = c("***", "**", "*", " ")),
                     label = "p.signif")+
  scale_fill_manual(values =c("#cc99ff", "#00d8e6"),
                    labels=c("Control","RA"))+
  labs(fill="Group")+
  #geom_dotplot(binaxis='y', stackdir='center', stackratio=1.5, dotsize=.8,binwidth = 1.5)+
  geom_boxplot(outlier.size=.5)+
  theme(panel.background = element_rect(fill = 'white'),
        panel.grid.minor.y = element_line(size=0),
        panel.grid.major = element_line(colour = "white"),
        plot.background = element_rect(fill="white"),
        axis.text.y = element_text(size = 6),
        axis.title.y=element_blank())
abun
