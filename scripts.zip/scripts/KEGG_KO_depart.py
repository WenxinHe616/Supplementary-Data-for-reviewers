file=open(r'2041_kos_2_rev5_uniq.txt')
output=open('gene-depart.txt','w')
for line in file:
    name=''
    koname=[]
    name=line.split(" ")[0].strip()
    koname=line.split(" ")[1].strip().split(",")
    for item in koname:
        print(name,item)
        output.write(name+'\t'+item+'\n')
file.close()
output.close()
