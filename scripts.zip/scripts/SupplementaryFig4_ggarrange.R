library(ggplot2)
library(tidyverse)
library(ggpubr)
td <- read.csv("2041genomes_genomesize.csv",header=T,sep = ",")
head(td)
my_comparisons <- list(c("human body","other mammal associated"),
                       c("human body","natural"),
                       c("human body","engineered"),
                       c("other mammal associated","natural"),
                       c("other mammal associated","engineered"),
                       c("natural","engineered"))
td_palette <- c("#f8766d","#e76bf3","#ffcb2c","#00bf7d","#00b0f6")
p1<-ggplot(td,aes(x=isolation_tag,y=genome_size,fill=isolation_tag))+
  scale_x_discrete(limits = c("human body","other mammal associated","insects","natural","engineered"),
                   labels = c("human body","other mammals","insects","natural","engineered"))+
  ylab("Genome size (Mbp)")+xlab("Isolation")+
  coord_cartesian(ylim=c(300000,2100000))+
  scale_y_continuous(breaks=c(300000,600000,900000,1200000,1500000),
                     labels = c(0.3,0.6,0.9,1.2,1.5))+
  labs(fill="Isolation")+
  geom_boxplot(outlier.size = .5,outlier.shape = 19,notch = FALSE)+
  stat_summary(fun.y = "mean", geom = "point",shape=23,size=1.5,fill="white")+
  stat_compare_means(comparisons = my_comparisons,
                     label = "p.format",
                     size=3,
                     hide.ns = FALSE,
                     method="wilcox.test")+
  scale_fill_manual(values=td_palette,limits=c("human body","other mammal associated","insects","natural","engineered"))+
  theme_bw()+
  theme(axis.title.x = element_blank(),
        axis.text.x = element_blank())
p1

my_comparisons <- list(c("human body","other mammal associated"),
                       c("human body","natural"),
                       c("human body","engineered"),
                       c("other mammal associated","natural"),
                       c("other mammal associated","engineered"),
                       c("natural","engineered"))
td_palette <- c("#f8766d","#e76bf3","#ffcb2c","#00bf7d","#00b0f6")
setwd("D:/work_station/000.TM7_1840version/01.genomedb/01.genomesize_genescounts")
td <- read.csv("2041genomes_proteinscounts.csv",header=T,sep = ",")
p2<-ggplot(td,aes(x=isolation_tag,y=protein_counts,fill=isolation_tag))+
  scale_x_discrete(limits = c("human body","other mammal associated","insects","natural","engineered"),
                   labels = c("human body","other mammals","insects","natural","engineered"))+
  ylab("Proteome size") + xlab("Genome isolation") + 
  coord_cartesian(ylim=c(400,2550))+
  scale_y_continuous(breaks=c(500,1000,1500,2000))+
  labs(fill="Isolation")+
  geom_boxplot(outlier.size = .5,outlier.shape = 19,notch = FALSE)+
  stat_summary(fun.y = "mean", geom = "point",shape=23,size=1.5,fill="white")+
  stat_compare_means(method = "wilcox.test",
                     comparisons = my_comparisons,
                     label = "p.format",
                     size=3,
                     hide.ns =FALSE)+ 
  scale_fill_manual(values=td_palette,limits=c("human body","other mammal associated","insects","natural","engineered"))+
  theme_bw()+
  theme(axis.title.x = element_blank(),
        axis.text.x = element_blank())
p2

ggarrange(p1,p2,ncol=2,nrow=1,
          align="h",
          common.legend=TRUE,
          legend="right")
