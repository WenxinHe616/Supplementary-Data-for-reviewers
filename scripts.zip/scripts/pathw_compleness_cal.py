#separate pathways
import pandas as pd
import numpy as np
import networkx as nx
df=pd.read_csv("./modules.csv")
#build module networks
def build_module_net(module_df):
    num_steps = max([int(i.split(',')[0]) for i in set(module_df['path'])])
    module_net = nx.DiGraph(num_steps=num_steps, module_id=list(module_df['module'])[0],
                            module_name=list(module_df['module_name'])[0])
    # go through all path/step combinations
    for module_path, frame in module_df.groupby('path'):
        split_path = [int(i) for i in module_path.split(',')]
        step = split_path[0]
        module_net.add_node(module_path, kos=set(frame['ko']))
            # add incoming edge
        if len(split_path)==2:
            if step==0:
                module_net.add_edge('end_step_%s' % num_steps, module_path)
            if step != 0:
                module_net.add_edge('end_step_%s' % (step - 1), module_path)
                # add outgoing edge
            module_net.add_edge(module_path, 'end_step_%s' % step)
        elif len(split_path)==4:
            if split_path[2]==0:
                if step==0:
                    module_net.add_edge('end_step_%s' % num_steps, module_path)
                elif step!=0:
                    module_net.add_edge('end_step_%s' % (step - 1), module_path)
            elif split_path[2]==1:
                module_net.add_edge(module_path, 'end_step_%s' % step)
        elif len(split_path)==6:
            if split_path[2]==0 :
                if step==0:
                    module_net.add_edge('end_step_%s' % num_steps, module_path)
                elif step!=0:
                    module_net.add_edge('end_step_%s' % (step - 1), module_path)
            elif split_path[2]==1:
                module_net.add_edge(module_path, 'end_step_%s' % step)
        else:
             print("Error! A bin more than 3 steps! ")
    return module_net

#calculate coverage
def calcu_coverage(kos,module_net):
    pruned_module_net = module_net.copy()
    module_kos_present = set()
    for node, data in module_net.nodes.items():
        if 'kos' in data:
            ko_overlap = data['kos'] & kos
            if len(ko_overlap) == 0:
                pruned_module_net.remove_node(node)
            else:
                module_kos_present = module_kos_present | ko_overlap
        # count number of missing steps
    missing_steps = 0
    last_step=''
    last_step='end_step_'+str(pruned_module_net.graph['num_steps'])
    for node, data in pruned_module_net.nodes.items():
        if ('end_step' in node) and (pruned_module_net.in_degree(node) == 0):
            missing_steps += 0.5
        if ('end_step' in node) and (pruned_module_net.out_degree(node) == 0):
            missing_steps += 0.5
        # get statistics
    num_steps = pruned_module_net.graph['num_steps'] + 1
    num_steps_present = num_steps - missing_steps
    coverage = num_steps_present / num_steps
    return coverage,module_kos_present

#ko_list2=[]
#ko_file=open("/Users/homer/Desktop/UHGP.KO.uniq.txt")
#for line in ko_file:
#    ko_list2.append(line.replace('\n',''))
#ko_list2=set(ko_list2)
#output=open('/Users/homer/Desktop/uhgp_com.txt','w')
#modules=sorted([i for i in set(df['module'])])
#title='strain'
#for i in modules:
#    title+=('\t'+i)
#title+='\n'
#output.write(title)
#output_str=''
#for i in modules:
#        df_module=df[df['module']==i]
#        module_name=df_module['module_name'].iloc[0]
#        network=build_module_net(df_module)
#        cover=calcu_coverage(ko_list2,network)
#        output_str+=str(cover)+'\t'
#output.write(output_str+'\n')

ko_list=[]
ko_file=pd.read_csv("./gene-depart_uniq.csv")
output=open('./path_com.txt','w')
output2=open('./com_modules.txt','w')
modules=sorted([i for i in set(df['module'])])
title='strain'
for i in modules:
    title+=('\t'+i)
title+='\n'
output.write(title)
genomes=[i for i in set(ko_file['strain'])]
for r in genomes:
    output_str=''
    strain_df=ko_file[ko_file['strain']==r]
    ko_list=strain_df['kos']
    ko_list=set(ko_list)
    modules=sorted([i for i in set(df['module'])])
    for i in modules:
        df_module=df[df['module']==i]
        module_name=df_module['module_name'].iloc[0]
        network=build_module_net(df_module)
        values=calcu_coverage(ko_list,network)
        cover=values[0]
        output_str+=str(cover)+'\t'
        if cover>0.5:
            output2.write(r+'\t'+str(values[1])+'\t'+i+'\n')
    output.write(r+'\t'+output_str+'\n')
output.close()
